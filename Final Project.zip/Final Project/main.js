$('#header').html('Hactiv8')

$('#header').css('color','red')

$('#header').click(function (){
    alert('header di klik' + $('#header').html())
})

$('#listanak').click(function() {
    alert('anak di klik')
})

$('#header').mouseover(function (){
    $('#header').css('color','blue')
})

$('#header').mouseleave(function (){
    $('#header').css('color','red')
})

$('#nama').val('hana')